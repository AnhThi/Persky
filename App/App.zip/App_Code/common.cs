﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public class common
{
    public static string manhanvien;
    public static string matkhau;
    public static string tenhanvien;
    public static string chucvu;
    public static string gioitinh;
    public static DateTime ngaysinh;
    public static string diachi;
    public static string sdt;
    public static string email;
    public static string trangthai;

}